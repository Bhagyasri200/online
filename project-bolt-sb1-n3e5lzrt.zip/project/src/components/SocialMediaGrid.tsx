import React from 'react';
import { SocialMediaPost } from '../data/social-media';

interface SocialMediaGridProps {
  posts: SocialMediaPost[];
  selectedCategory: string;
}

export function SocialMediaGrid({ posts, selectedCategory }: SocialMediaGridProps) {
  const filteredPosts = selectedCategory === 'All'
    ? posts
    : posts.filter(post => post.category === selectedCategory);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {filteredPosts.map(post => (
        <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
          <img
            src={post.image}
            alt={post.altText}
            className="w-full h-64 object-cover"
          />
          <div className="p-4">
            <p className="text-sm text-gray-600 mb-2">{post.category}</p>
            <p className="text-gray-800 mb-3">{post.caption}</p>
            <div className="flex flex-wrap gap-2">
              {post.hashtags.map(tag => (
                <span
                  key={tag}
                  className="text-xs text-blue-600 hover:text-blue-800 cursor-pointer"
                >
                  {tag}
                </span>
              ))}
            </div>
            <div className="mt-3 text-xs text-gray-500">
              <p>Instagram: {post.dimensions.instagram}</p>
              <p>Facebook: {post.dimensions.facebook}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}