export const products = [
  // Electronics
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=60",
    description: "High-quality wireless headphones with noise cancellation",
    category: "Electronics"
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    price: 299.99,
    image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=60",
    description: "Advanced smartwatch with health tracking features",
    category: "Electronics"
  },
  {
    id: 3,
    name: "4K Drone Camera",
    price: 799.99,
    image: "https://images.unsplash.com/photo-1579829366248-204fe8413f31?w=800&auto=format&fit=crop&q=60",
    description: "Professional drone with 4K camera and stabilization",
    category: "Electronics"
  },
  {
    id: 4,
    name: "Wireless Gaming Mouse",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=800&auto=format&fit=crop&q=60",
    description: "Ultra-responsive gaming mouse with RGB lighting",
    category: "Electronics"
  },

  // Fashion
  {
    id: 5,
    name: "Designer Backpack",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=60",
    description: "Stylish and practical backpack for everyday use",
    category: "Fashion"
  },
  {
    id: 6,
    name: "Leather Wallet",
    price: 49.99,
    image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&auto=format&fit=crop&q=60",
    description: "Genuine leather wallet with RFID protection",
    category: "Fashion"
  },
  {
    id: 7,
    name: "Aviator Sunglasses",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&auto=format&fit=crop&q=60",
    description: "Classic aviator sunglasses with UV protection",
    category: "Fashion"
  },
  {
    id: 8,
    name: "Running Shoes",
    price: 159.99,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=60",
    description: "Lightweight running shoes with superior cushioning",
    category: "Fashion"
  },

  // Home & Living
  {
    id: 9,
    name: "Premium Coffee Maker",
    price: 159.99,
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&auto=format&fit=crop&q=60",
    description: "Professional-grade coffee maker for perfect brews",
    category: "Home"
  },
  {
    id: 10,
    name: "Smart LED Bulb Set",
    price: 49.99,
    image: "https://images.unsplash.com/photo-1550525811-e5869dd03032?w=800&auto=format&fit=crop&q=60",
    description: "WiFi-enabled LED bulbs with millions of colors",
    category: "Home"
  },
  {
    id: 11,
    name: "Bamboo Cutting Board",
    price: 34.99,
    image: "https://images.unsplash.com/photo-1544441893-675973e31985?w=800&auto=format&fit=crop&q=60",
    description: "Eco-friendly bamboo cutting board with juice groove",
    category: "Home"
  },
  {
    id: 12,
    name: "Robot Vacuum Cleaner",
    price: 299.99,
    image: "https://images.unsplash.com/photo-1518640467707-6811f4a6ab73?w=800&auto=format&fit=crop&q=60",
    description: "Smart robot vacuum with mapping technology",
    category: "Home"
  },

  // Sports & Outdoors
  {
    id: 13,
    name: "Yoga Mat",
    price: 29.99,
    image: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=800&auto=format&fit=crop&q=60",
    description: "Non-slip yoga mat with carrying strap",
    category: "Sports"
  },
  {
    id: 14,
    name: "Mountain Bike",
    price: 799.99,
    image: "https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=800&auto=format&fit=crop&q=60",
    description: "All-terrain mountain bike with 21 speeds",
    category: "Sports"
  },
  {
    id: 15,
    name: "Camping Tent",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=800&auto=format&fit=crop&q=60",
    description: "4-person waterproof camping tent",
    category: "Sports"
  },
  {
    id: 16,
    name: "Fitness Tracker",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1557935728-e6d1eaabe558?w=800&auto=format&fit=crop&q=60",
    description: "Advanced fitness tracker with heart rate monitoring",
    category: "Sports"
  }
];