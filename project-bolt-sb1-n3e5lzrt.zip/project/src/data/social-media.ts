export interface SocialMediaPost {
  id: number;
  category: string;
  image: string;
  caption: string;
  altText: string;
  hashtags: string[];
  dimensions: {
    instagram: string;
    facebook: string;
  };
}

export const socialMediaPosts: SocialMediaPost[] = [
  // Motivational Quotes
  {
    id: 1,
    category: "Motivational",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&auto=format&fit=crop&q=60",
    caption: "Your only limit is your mind. Push beyond what you think is possible.",
    altText: "Stunning mountain peak at sunrise with misty valleys below",
    hashtags: ["#MondayMotivation", "#InspirationDaily", "#DreamBig", "#GoalSetter"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },
  
  // Workplace Humor
  {
    id: 2,
    category: "Workplace",
    image: "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?w=1200&auto=format&fit=crop&q=60",
    caption: "That moment when you realize it's only Tuesday... Time for more coffee!",
    altText: "Desktop workspace with coffee cup and laptop",
    hashtags: ["#OfficeLife", "#WorkLife", "#CorporateHumor", "#NeedCoffee"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Food and Recipes
  {
    id: 3,
    category: "Food",
    image: "https://images.unsplash.com/photo-1499028344343-cd173ffc68a9?w=1200&auto=format&fit=crop&q=60",
    caption: "Weekend brunch goals! 🍳 Swipe for the full recipe!",
    altText: "Beautifully plated breakfast spread with avocado toast and eggs",
    hashtags: ["#FoodLover", "#Foodstagram", "#BrunchGoals", "#RecipeShare"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Pet Moments
  {
    id: 4,
    category: "Pets",
    image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=1200&auto=format&fit=crop&q=60",
    caption: "When they give you this look... who can resist? 😻",
    altText: "Close-up of cat with bright blue eyes looking at camera",
    hashtags: ["#CatsOfInstagram", "#PetLove", "#AdoptDontShop", "#CutePets"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Travel
  {
    id: 5,
    category: "Travel",
    image: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?w=1200&auto=format&fit=crop&q=60",
    caption: "Paradise found 🌴 Sometimes getting lost leads to the best destinations",
    altText: "Aerial view of tropical island with crystal clear waters",
    hashtags: ["#TravelLife", "#Wanderlust", "#Paradise", "#TravelPhotography"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Fitness
  {
    id: 6,
    category: "Fitness",
    image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&auto=format&fit=crop&q=60",
    caption: "Your body can do it. It's time to convince your mind! 💪",
    altText: "Person doing yoga pose at sunset on beach",
    hashtags: ["#FitnessMotivation", "#HealthyLifestyle", "#WorkoutTime", "#FitLife"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Tech
  {
    id: 7,
    category: "Tech",
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=60",
    caption: "The future is here! Check out these game-changing innovations 🚀",
    altText: "Modern workspace with multiple screens and LED lighting",
    hashtags: ["#TechNews", "#Innovation", "#FutureTech", "#TechnologyRocks"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Self-care
  {
    id: 8,
    category: "Self-care",
    image: "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=1200&auto=format&fit=crop&q=60",
    caption: "Taking time for yourself isn't selfish, it's necessary 🧘‍♀️",
    altText: "Peaceful meditation space with candles and plants",
    hashtags: ["#SelfCare", "#MentalHealth", "#Mindfulness", "#WellnessJourney"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Home Organization
  {
    id: 9,
    category: "Home",
    image: "https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?w=1200&auto=format&fit=crop&q=60",
    caption: "A tidy space = a tidy mind ✨ Swipe for organization tips!",
    altText: "Beautifully organized closet with color-coordinated items",
    hashtags: ["#HomeOrganization", "#CleanSpace", "#OrganizedLife", "#HomeInspo"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Outdoor Adventures
  {
    id: 10,
    category: "Outdoors",
    image: "https://images.unsplash.com/photo-1501555088652-021faa106b9b?w=1200&auto=format&fit=crop&q=60",
    caption: "Adventure awaits! What's your next destination? 🏔️",
    altText: "Hiker standing on mountain peak overlooking valley",
    hashtags: ["#AdventureTime", "#ExploreMore", "#NatureLover", "#Hiking"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Coffee
  {
    id: 11,
    category: "Coffee",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1200&auto=format&fit=crop&q=60",
    caption: "But first, coffee ☕ Starting the day right!",
    altText: "Artistically prepared latte with heart-shaped foam art",
    hashtags: ["#CoffeeLover", "#MorningRoutine", "#CoffeeTime", "#ButFirstCoffee"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Books
  {
    id: 12,
    category: "Books",
    image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=1200&auto=format&fit=crop&q=60",
    caption: "Lost in a good book 📚 What are you reading this weekend?",
    altText: "Cozy reading nook with books and warm lighting",
    hashtags: ["#BookLover", "#ReadMore", "#Bookstagram", "#ReadersOfInstagram"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Friendship
  {
    id: 13,
    category: "Friendship",
    image: "https://images.unsplash.com/photo-1516149893016-813d9a01d5d3?w=1200&auto=format&fit=crop&q=60",
    caption: "Friends who laugh together, stay together 👯‍♀️",
    altText: "Group of friends laughing together outdoors",
    hashtags: ["#FriendshipGoals", "#BestFriends", "#GoodTimes", "#Memories"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Urban Life
  {
    id: 14,
    category: "Urban",
    image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1200&auto=format&fit=crop&q=60",
    caption: "City lights and urban nights 🌃",
    altText: "Dramatic cityscape at night with illuminated buildings",
    hashtags: ["#CityLife", "#UrbanPhotography", "#CityVibes", "#NightLife"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // DIY
  {
    id: 15,
    category: "DIY",
    image: "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=1200&auto=format&fit=crop&q=60",
    caption: "Made with love ❤️ Swipe for the full DIY tutorial!",
    altText: "Crafting workspace with art supplies and work in progress",
    hashtags: ["#DIYProject", "#Crafting", "#HandmadeWithLove", "#CreativeLife"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  // Additional Categories
  {
    id: 16,
    category: "Wellness",
    image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1200&auto=format&fit=crop&q=60",
    caption: "Nourish your body, mind, and soul 🌿",
    altText: "Healthy breakfast bowl with fresh fruits and superfoods",
    hashtags: ["#WellnessJourney", "#HealthyLiving", "#MindBodySoul", "#CleanEating"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  {
    id: 17,
    category: "Art",
    image: "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=1200&auto=format&fit=crop&q=60",
    caption: "Every artist was first an amateur 🎨",
    altText: "Colorful abstract painting in progress",
    hashtags: ["#ArtisticSoul", "#CreateDaily", "#ArtistsOfInstagram", "#CreativeProcess"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  {
    id: 18,
    category: "Gardening",
    image: "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=1200&auto=format&fit=crop&q=60",
    caption: "Grow with love 🌱 Spring garden tips inside!",
    altText: "Beautiful garden with blooming flowers and herbs",
    hashtags: ["#GardenLife", "#GrowYourOwn", "#GardenLove", "#PlantCare"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  {
    id: 19,
    category: "Music",
    image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=1200&auto=format&fit=crop&q=60",
    caption: "Music speaks what words cannot 🎵",
    altText: "Vintage record player with vinyl records",
    hashtags: ["#MusicLover", "#VinylCollection", "#GoodVibes", "#MusicIsLife"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  },

  {
    id: 20,
    category: "Sustainability",
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=1200&auto=format&fit=crop&q=60",
    caption: "Small changes, big impact 🌍 Tips for sustainable living",
    altText: "Zero waste products and reusable items",
    hashtags: ["#SustainableLiving", "#ZeroWaste", "#EcoFriendly", "#SaveThePlanet"],
    dimensions: {
      instagram: "1080x1080",
      facebook: "1200x630"
    }
  }
];